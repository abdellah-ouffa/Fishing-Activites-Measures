<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
   
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/font/iconsmind-s/css/iconsminds.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/font/simple-line-icons/css/simple-line-icons.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor/bootstrap.rtl.only.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor/component-custom-switch.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor/component-custom-switch.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor/sweetalert.css')); ?>"/>
    
    <link href="<?php echo e(asset("assets/css/app.css")); ?>" rel="stylesheet"/>

    <?php echo $__env->yieldContent('plugin-stylesheet'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">

    <script>
        window.assetsUrl = "<?php echo e(asset('/')); ?>";
        window.baseUrl = "<?php echo e(url('/')); ?>";
        window.currentScolarYear = "<?php echo e(config('scholaryear.current_scholar_year')); ?>";
    </script>

    <?php echo $__env->yieldContent('custom-stylesheet'); ?>
</head>

<body id="app-container" class="menu-default show-spinner">

    <?php echo $__env->make('layouts.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main id="app-root">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="<?php echo e(asset('assets/js/vendor/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/mousetrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/sweetalert.js')); ?>" type="text/javascript"></script>
    
    <?php echo $__env->yieldContent('plugin-javascript'); ?>
    
    <script src="<?php echo e(asset('assets/js/dore.script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.link-type').click(function () {
                window.location.href = $(this).data('url');
            });

            try {
                $('.datepicker').datepicker({
                    format: 'dd/mm/yyyy',
                });
            } catch (e) {
                // console.log(e)
            }

            $('.btn-delete-resource').click(function (event) {
                event.preventDefault();
                alert('test')
                // var form = $(this).data('form-id') != null ? $('#' + $(this).data('form-id')) : $(this).parent();
                // if($(this).hasClass('redirect-after-confirmation')) {
                //     swal.queue([{
                //         title: 'Etes-vous sûr?',
                //         text: $(this).data('confirmation-message'),
                //         type: 'warning',
                //         showCancelButton: true,
                //         confirmButtonColor: '#3085d6',
                //         cancelButtonColor: '#d33',
                //         confirmButtonText: 'Oui, Supprimer!',
                //         showLoaderOnConfirm: true,
                //         preConfirm:()  => {
                //             return new Promise((resolve) =>  {
                //                 // form.submit();
                //             })
                //         }
                //     }])
                // }
            });
        })
    </script>

    <?php echo $__env->yieldContent('custom-javascript'); ?>
    
    <script src="<?php echo e(asset("assets/js/app.js")); ?>" defer></script>

    <?php echo $__env->make('layouts.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\lab\fishing-activites-measures\web\resources\views/layouts/master.blade.php ENDPATH**/ ?>