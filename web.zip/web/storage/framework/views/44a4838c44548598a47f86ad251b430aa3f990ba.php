<script type="text/javascript">
	$(document).ready(function(){
		<?php if(Session::has('success')): ?>
			messageBox("", "L'enregistrement a été effectué avec succès", "success");
		<?php endif; ?>
		<?php if(Session::has('error')): ?>
			messageBox("", "<?php echo e(Session::get('error')); ?>", "error");
		<?php endif; ?>
		function messageBox(title, content, type) {
			setTimeout(function () {
				swal(
					title,
					content,
					type
				);
			}, 1000);
		}
	});
</script><?php /**PATH C:\xampp\htdocs\lab\fishing-activites-measures\web\resources\views/layouts/includes/messages.blade.php ENDPATH**/ ?>