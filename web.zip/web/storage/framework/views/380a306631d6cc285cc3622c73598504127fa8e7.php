<?php $__env->startSection('title', 'Ajouter nouveau administrateur'); ?>

<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row">
            <div class="col-12">
                <h1>Nouveau administrateur</h1>
                <div class="top-right-button-container mb-4">
                    <button data-url="<?php echo e(route('admins.index')); ?>" type="button" class="btn btn-primary btn-lg top-right-button link-type">Liste des administrateurs</button>
                </div>
                <nav class="breadcrumb-container d-none d-sm-block d-lg-inline-block" aria-label="breadcrumb">
                    <ol class="breadcrumb pt-0">
                        <li class="breadcrumb-item">
                            <a href="#">Tableau de board</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.index')); ?>">Admins</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Nouveau administrateur</li>
                    </ol>
                </nav>
                <div class="separator mb-5"></div>
            </div>
        </div>

		<form action="<?php echo e(route('admins.store')); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
		    <div class="row">
		    	<div class="col-md-3">
		    		<div class="card mb-4">
	                    <div class="card-body text-center">
	                        <h5 class="text-left">Photo</h5>
	                        <div class="separator mb-4"></div>
	                    	<img id="user-picture" class="img-circle" style="width: 150px; height: 150px;" src="<?php echo e(asset('assets/img/profile-pic-l.jpg')); ?>" >
	                    	<input type="file" class="hide" name="picture" id="file-user-picture">
	                    </div>
	                    <div class="card-footer bg-white">
	                    	<button id="select-user-picture" type="button" class="btn btn-primary btn-block">Choisir une image</button>
	                    </div>
	                </div>
		    	</div>

		    	<div class="col-md-9">
		    		<div class="card mb-4">
	                    <div class="card-body">
	                        <h5>Informations personnel</h5>
	                    	<div class="separator mb-4"></div>	                        
	                        <div class="row">
	                        	<div class="col-md-6">
		                            <div class="form-group">
		                                <label for="first_name">Nom</label>
		                                <input type="text" class="form-control <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="first_name" id="first_name" value="<?php echo e(old('first_name')); ?>" placeholder="Nom">
		                            	<?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
		                                    <span class="invalid-feedback" role="alert">
		                                        <strong><?php echo e($message); ?></strong>
		                                    </span>
		                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		                            </div>
	                        	</div>
	                        	<div class="col-md-6">
		                            <div class="form-group">
		                                <label for="last_name">Prénom</label>
		                                <input type="text" class="form-control <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="last_name" id="last_name" value="<?php echo e(old('last_name')); ?>" placeholder="Prénom">
		                            	<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
		                                    <span class="invalid-feedback" role="alert">
		                                        <strong><?php echo e($message); ?></strong>
		                                    </span>
		                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		                            </div>
	                        	</div>
	                        </div>

	                        <h5 class="mt-4">Accès au plateforme <span class="text-danger text-small">[Mobile]</span></h5>
	                        <div class="separator mb-4"></div>
							<div class="form-group">
							    <label for="ppr_number">PPR</label>
							    <input type="text" class="form-control <?php if ($errors->has('ppr_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ppr_number'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="ppr_number" id="ppr_number" value="<?php echo e(old('ppr_number')); ?>" placeholder="PPR">
								<?php if ($errors->has('ppr_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ppr_number'); ?>
							        <span class="invalid-feedback" role="alert">
							            <strong><?php echo e($message); ?></strong>
							        </span>
							    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
	                        
	                        <h5 class="mt-4">Accès au plateforme <span class="text-danger text-small">[Web]</span></h5>
	                        <div class="separator mb-4"></div>
							<div class="row">
		                        <div class="col-md-6">
									<div class="form-group">
									    <label for="email">E-mail</label>
									    <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail">
										<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
									        <span class="invalid-feedback" role="alert">
									            <strong><?php echo e($message); ?></strong>
									        </span>
									    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
		                        </div>
								<div class="col-md-3">
							        <div class="form-group">
							            <label for="password">Mot de passe</label>
							            <input type="password" class="form-control" name="password" id="password" value="<?php echo e(old('password')); ?>" placeholder="Mot de passe">
							        </div>
								</div>
								<div class="col-md-3">
							        <div class="form-group mb-0">
							            <label for="password_confirmation">Confirmation</label>
							            <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirmation">
							        </div>
								</div>
							</div>

							<div class="mt-4"></div>
                            <button type="submit" class="float-right btn btn-primary mb-0">Enregistrer</button>
	                    </div>
	                </div>
		    	</div>
		    </div>
			
		</form>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-stylesheet'); ?>
	<style>
		.img-circle {
			border-radius: 50%;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-javascript'); ?>
	<script type="text/javascript">
		$(document).ready(function () {
			$('#select-user-picture').click(function () {
				$('#file-user-picture').click();
			});
			
			$('#file-user-picture').change(function () {
				$('#user-picture').attr(
					'src', window.URL.createObjectURL(this.files[0])
				);
			});
		})
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lab\fishing-activites-measures\web\resources\views/admin/admins/create.blade.php ENDPATH**/ ?>